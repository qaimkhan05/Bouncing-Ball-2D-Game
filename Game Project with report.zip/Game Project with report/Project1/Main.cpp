
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <fstream>
#include <algorithm>
#include <string>
#include <iostream>
#include <random>

//This game is For Sir ABDUL RAHEEM ALEEM.
//The Best Teacher in the world.


enum GameState { HOME, INSTRUCTIONS, CREDITS, PLAYING, PAUSED, GAME_OVER, SETTINGS };

sf::Color getRandomColor() {
    static std::vector<sf::Color> colors = {
        sf::Color::Red, sf::Color::Green, sf::Color::Blue,
        sf::Color::Yellow, sf::Color::Magenta, sf::Color::Cyan,
        sf::Color(255, 165, 0), sf::Color(128, 0, 128), sf::Color(0, 255, 127)
    };
    static std::mt19937 rng(static_cast<unsigned>(time(nullptr)));
    std::uniform_int_distribution<int> dist(0, colors.size() - 1);
    return colors[dist(rng)];
}

class GameObject {
public:
    virtual void update(float dt) {}
    virtual void draw(sf::RenderWindow& window) = 0;
    virtual sf::FloatRect getBounds() const=0;
    virtual ~GameObject() {}
};


class Paddle : public GameObject {
public:
    sf::ConvexShape shape;
    float speed = 700.f;

    Paddle(float x, float y) {
        shape.setPointCount(4);
        shape.setPoint(0, sf::Vector2f(-80.f, -10.f));
        shape.setPoint(1, sf::Vector2f(80.f, -10.f));
        shape.setPoint(2, sf::Vector2f(60.f, 10.f));
        shape.setPoint(3, sf::Vector2f(-60.f, 10.f));
        shape.setFillColor(sf::Color(128, 128, 128));
        shape.setOutlineThickness(3);
        shape.setOutlineColor(sf::Color::White);
        shape.setOrigin(0, 0);
        shape.setPosition(x, y);
    }

    void move(float dx) {
        shape.move(dx, 0);
        if (shape.getPosition().x - 80.f < 0)
            shape.setPosition(80.f, shape.getPosition().y);
        if (shape.getPosition().x + 80.f > 1280)
            shape.setPosition(1280 - 80.f, shape.getPosition().y);
    }

    void draw(sf::RenderWindow& window) override {
        window.draw(shape);
    }

    sf::FloatRect getBounds() const override {
        return shape.getGlobalBounds();
    }
};


class Ball : public GameObject {
public:
    sf::CircleShape shape;
    sf::Vector2f velocity{ -300.f, -300.f };

    Ball(float x, float y) {
        shape.setRadius(12.f);
        shape.setFillColor(sf::Color::White);
        shape.setOutlineThickness(2);
        shape.setOutlineColor(sf::Color::White);
        shape.setOrigin(12.f, 12.f);
        shape.setPosition(x, y);
    }

    void update(float dt) override {
        shape.move(velocity * dt);
    }

    void draw(sf::RenderWindow& window) override {
        window.draw(shape);
    }

    sf::FloatRect getBounds() const override {
        return shape.getGlobalBounds();
    }
};

class Brick : public GameObject {
public:
    sf::RectangleShape shape;
    bool destroyed = false;

    Brick(float x, float y) {
        shape.setSize({ 60.f, 20.f });
        shape.setFillColor(getRandomColor());
        shape.setOutlineThickness(1);
        shape.setOutlineColor(sf::Color::Black);
        shape.setPosition(x, y);
    }

    void draw(sf::RenderWindow& window) override {
        if (!destroyed)
            window.draw(shape);
    }

    sf::FloatRect getBounds() const override {
        return shape.getGlobalBounds();
    }
};


void drawFancyText(sf::RenderWindow& window, const std::string& str, sf::Font& font, int size, float x, float y,
    sf::Color fillColor = sf::Color::White, sf::Color outlineColor = sf::Color::Black,
    float outlineThickness = 2.f, bool bold = false) {
    sf::Text text(str, font, size);
    text.setPosition(x, y);
    text.setFillColor(fillColor);
    text.setOutlineColor(outlineColor);
    text.setOutlineThickness(outlineThickness);
    if (bold) text.setStyle(sf::Text::Bold);

    // Shadow effect
    sf::Text shadow = text;
    shadow.setFillColor(sf::Color(0, 0, 0, 150));
    shadow.setOutlineColor(sf::Color::Transparent);
    shadow.setPosition(x + 3, y + 3);
    window.draw(shadow);

    window.draw(text);
}

void drawMenuText(sf::RenderWindow& window, const std::string& str, sf::Font& font, int size, float x, float y, bool isSelected) {
    sf::Color fillColor = isSelected ? sf::Color(255, 215, 0) : sf::Color(200, 200, 200);
    sf::Color outlineColor = isSelected ? sf::Color(139, 69, 19) : sf::Color(50, 50, 50);
    float thickness = isSelected ? 3.f : 1.5f;

    drawFancyText(window, str, font, size, x, y, fillColor, outlineColor, thickness, isSelected);
}

void saveGame(const Ball& ball, const Paddle& paddle, int score, int lives, int level) {
    std::ofstream file("save.txt");
    file << ball.shape.getPosition().x << ' ' << ball.shape.getPosition().y << ' ';
    file << paddle.shape.getPosition().x << ' ' << score << ' ' << lives << ' ' << level << '\n';
    file.close();
}

void loadGame(Ball& ball, Paddle& paddle, int& score, int& lives, int& level) {
    std::ifstream file("save.txt");
    float bx, by, px;
    if (file >> bx >> by >> px >> score >> lives >> level) {
        ball.shape.setPosition(bx, by);
        paddle.shape.setPosition(px, paddle.shape.getPosition().y);
    }
    file.close();
}

void resetBricks(std::vector<Brick>& bricks, int level) {
    bricks.clear();
    for (int i = 0; i < 5 + level; ++i) {
        for (int j = 0; j < 17; ++j) {
            bricks.emplace_back(70.f * j + 10, 30.f * i + 50);
        }
    }
}

void handleMenu(sf::RenderWindow& window, sf::Font& font, int& menuIndex) {
    std::vector<std::string> menu = { "Start New Game", "Load Game (L)", "Instructions (I)", "Credits (C)", "Settings (O)", "Quit Game (Q)" };

    // Game title with fancy effect
    drawFancyText(window, "BOUNCE BALL 2D", font, 80, 360, 80,
        sf::Color(255, 215, 0), sf::Color(139, 69, 19), 4.f, true);

    // Subtitle
    drawFancyText(window, "The Ultimate Brick Breaker For (Sir ABDUL RAHEEM ALEEM)", font, 24, 460, 160,
        sf::Color(200, 200, 200), sf::Color::Transparent, 0.f);

    // Menu items
    for (int i = 0; i < (int)menu.size(); ++i) {
        drawMenuText(window, menu[i], font, 42, 480, 220 + i * 70, (i == menuIndex));
    }

    // Controls hint
    drawFancyText(window, "Use ARROW KEYS to navigate, ENTER to select", font, 22, 420, 650,
        sf::Color(180, 180, 180), sf::Color::Transparent, 0.f);

    static bool keyPressed = false;
    if (!keyPressed && sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && menuIndex > 0) {
        menuIndex--;
        keyPressed = true;
    }
    if (!keyPressed && sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && menuIndex < (int)menu.size() - 1) {
        menuIndex++;
        keyPressed = true;
    }
    if (!sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && !sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
        keyPressed = false;
    }
}

int main() {
    sf::RenderWindow window(sf::VideoMode(1280, 720), "BOUNCE BALL 2D", sf::Style::Fullscreen);
    window.setFramerateLimit(60);
    sf::Clock clock;
    GameState state = HOME;
    int menuIndex = 0;
    int settingsIndex = 0;
    bool bgMusicOn = true;
    bool sfxOn = true;
    float bgMusicVolume = 50.f;
    float sfxVolume = 70.f;
    int highScore = 0;

    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) {
        std::cerr << "Failed to load font 'arial.ttf'\n";
        return -1;
    }

    sf::Texture backgroundTexture;
    if (!backgroundTexture.loadFromFile("Paddle Game.png")) {
        std::cerr << "Failed to load background image 'Paddle Game.png'\n";
        return -1;
    }
    sf::Sprite backgroundSprite(backgroundTexture);
    backgroundSprite.setScale(
        1280.f / backgroundTexture.getSize().x,
        720.f / backgroundTexture.getSize().y
    );

    sf::SoundBuffer hitBuffer;
    if (!hitBuffer.loadFromFile("hit.wav")) {
        std::cerr << "Failed to load sound 'hit.wav'\n";
    }
    sf::Sound hitSound(hitBuffer);
    hitSound.setVolume(sfxVolume);

    sf::Music bgMusic;
    if (!bgMusic.openFromFile("background.ogg")) {
        std::cerr << "Failed to load music 'background.ogg'\n";
    }
    else {
        bgMusic.setLoop(true);
        bgMusic.setVolume(bgMusicVolume);
        bgMusic.play();
    }

    Paddle paddle(640.f, 680.f);
    Ball ball(640.f, 500.f);
    std::vector<Brick> bricks;
    int score = 0, lives = 3, level = 1;
    resetBricks(bricks, level);

    while (window.isOpen()) {
        float dt = clock.restart().asSeconds();
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        // Global key controls
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Q)) {
            window.close();
        }

        // Quick access keys - only work in HOME state
        if (state == HOME) {
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::L)) {
                loadGame(ball, paddle, score, lives, level);
                resetBricks(bricks, level);
                state = PLAYING;
            }
            else if (sf::Keyboard::isKeyPressed(sf::Keyboard::I)) {
                state = INSTRUCTIONS;
            }
            else if (sf::Keyboard::isKeyPressed(sf::Keyboard::C)) {
                state = CREDITS;
            }
            else if (sf::Keyboard::isKeyPressed(sf::Keyboard::O)) {
                state = SETTINGS;
                settingsIndex = 0;
            }
        }

        // Back to menu from various screens
        if ((state == INSTRUCTIONS || state == CREDITS || state == SETTINGS || state == GAME_OVER) &&
            sf::Keyboard::isKeyPressed(sf::Keyboard::Escape)) {
            state = HOME;
        }

        window.clear();
        window.draw(backgroundSprite);

        if (state == HOME) {
            handleMenu(window, font, menuIndex);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter)) {
                if (menuIndex == 0) {
                    score = 0; lives = 3; level = 1;
                    ball = Ball(640.f, 500.f);
                    paddle = Paddle(640.f, 680.f);
                    resetBricks(bricks, level);
                    state = PLAYING;
                }
                else if (menuIndex == 1) {
                    loadGame(ball, paddle, score, lives, level);
                    resetBricks(bricks, level);
                    state = PLAYING;
                }
                else if (menuIndex == 2) {
                    state = INSTRUCTIONS;
                }
                else if (menuIndex == 3) {
                    state = CREDITS;
                }
                else if (menuIndex == 4) {
                    state = SETTINGS;
                    settingsIndex = 0;
                }
                else if (menuIndex == 5) {
                    window.close();
                }
            }
        }
        else if (state == INSTRUCTIONS) {
            drawFancyText(window, "GAME INSTRUCTIONS", font, 60, 420, 80,
                sf::Color(255, 215, 0), sf::Color(139, 69, 19), 3.f, true);

            drawFancyText(window, "Game Controls:", font, 36, 100, 180,
                sf::Color(100, 255, 100), sf::Color::Transparent, 0.f, true);

            drawFancyText(window, "Move Paddle: LEFT/RIGHT Arrow Keys", font, 28, 150, 240);
            drawFancyText(window, "Pause Game: P", font, 28, 150, 280);
            drawFancyText(window, "Save Game: S (During Gameplay)", font, 28, 150, 320);
            drawFancyText(window, "Quit Game: Q", font, 28, 150, 360);

            drawFancyText(window, "Menu Navigation:", font, 36, 100, 420,
                sf::Color(100, 255, 100), sf::Color::Transparent, 0.f, true);

            drawFancyText(window, "Load Game: L (From Main Menu)", font, 28, 150, 480);
            drawFancyText(window, "View Instructions: I (From Main Menu)", font, 28, 150, 520);
            drawFancyText(window, "View Credits: C (From Main Menu)", font, 28, 150, 560);
            drawFancyText(window, "Settings: O (From Main Menu)", font, 28, 150, 600);
            drawFancyText(window, "Go Back: ESC", font, 28, 150, 640);

            drawFancyText(window, "Press ESC to go back to Main Menu", font, 28, 450, 650,
                sf::Color(180, 180, 180), sf::Color::Transparent, 0.f);
        }
        else if (state == CREDITS) {
            drawFancyText(window, "GAME CREDITS", font, 70, 440, 80,
                sf::Color(255, 215, 0), sf::Color(139, 69, 19), 3.f, true);

            drawFancyText(window, "Designed & Developed By", font, 36, 480, 180,
                sf::Color(100, 255, 100), sf::Color::Transparent, 0.f, true);

            drawFancyText(window, "QAIM KHAN", font, 32, 520, 240, sf::Color::Cyan);
            drawFancyText(window, "ABDUL RAFAY", font, 32, 520, 280, sf::Color::Cyan);

            drawFancyText(window, "Contact Information", font, 36, 480, 360,
                sf::Color(100, 255, 100), sf::Color::Transparent, 0.f, true);

            drawFancyText(window, "Email: Qaim22994@gmail.com", font, 32, 520, 400, sf::Color::Cyan);
            drawFancyText(window, "Email: PrinceRafay751@gmail.com", font, 32, 520, 440, sf::Color::Cyan);


            drawFancyText(window, "Press ESC to go back to Main Menu", font, 28, 450, 650,
                sf::Color(180, 180, 180), sf::Color::Transparent, 0.f);
        }
        else if (state == SETTINGS) {
            drawFancyText(window, "GAME SETTINGS", font, 70, 440, 80,
                sf::Color(255, 215, 0), sf::Color(139, 69, 19), 3.f, true);

            // Background Music toggle
            drawMenuText(window, "Background Music: " + std::string(bgMusicOn ? "ON" : "OFF"),
                font, 36, 450, 220, (settingsIndex == 0));

            // Background Music volume
            drawMenuText(window, "Music Volume: " + std::to_string((int)bgMusicVolume),
                font, 36, 450, 280, (settingsIndex == 1));

            // SFX toggle
            drawMenuText(window, "Sound Effects: " + std::string(sfxOn ? "ON" : "OFF"),
                font, 36, 450, 340, (settingsIndex == 2));

            // SFX volume
            drawMenuText(window, "SFX Volume: " + std::to_string((int)sfxVolume),
                font, 36, 450, 400, (settingsIndex == 3));

            // Back to menu
            drawMenuText(window, "Back to Main Menu",
                font, 36, 450, 460, (settingsIndex == 4));

            // Controls hint
            drawFancyText(window, "Use ARROW KEYS to navigate, ENTER to toggle/select", font, 22, 400, 650,
                sf::Color(180, 180, 180), sf::Color::Transparent, 0.f);

            // Handle settings navigation
            static bool keyPressed = false;
            if (!keyPressed) {
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && settingsIndex > 0) {
                    settingsIndex--;
                    keyPressed = true;
                }
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && settingsIndex < 4) {
                    settingsIndex++;
                    keyPressed = true;
                }

                // Volume controls
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
                    if (settingsIndex == 1 && bgMusicVolume > 0) {
                        bgMusicVolume -= 5.f;
                        if (bgMusicVolume < 0) bgMusicVolume = 0;
                        bgMusic.setVolume(bgMusicVolume);
                        keyPressed = true;
                    }
                    else if (settingsIndex == 3 && sfxVolume > 0) {
                        sfxVolume -= 5.f;
                        if (sfxVolume < 0) sfxVolume = 0;
                        hitSound.setVolume(sfxVolume);
                        keyPressed = true;
                    }
                }
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
                    if (settingsIndex == 1 && bgMusicVolume < 100) {
                        bgMusicVolume += 5.f;
                        if (bgMusicVolume > 100) bgMusicVolume = 100;
                        bgMusic.setVolume(bgMusicVolume);
                        keyPressed = true;
                    }
                    else if (settingsIndex == 3 && sfxVolume < 100) {
                        sfxVolume += 5.f;
                        if (sfxVolume > 100) sfxVolume = 100;
                        hitSound.setVolume(sfxVolume);
                        keyPressed = true;
                    }
                }

                // Toggle options or execute actions
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter)) {
                    if (settingsIndex == 0) {
                        bgMusicOn = !bgMusicOn;
                        if (bgMusicOn) bgMusic.play();
                        else bgMusic.pause();
                    }
                    else if (settingsIndex == 2) {
                        sfxOn = !sfxOn;
                    }
                    else if (settingsIndex == 4) {
                        state = HOME;
                    }
                    keyPressed = true;
                }
            }

            if (!sf::Keyboard::isKeyPressed(sf::Keyboard::Up) &&
                !sf::Keyboard::isKeyPressed(sf::Keyboard::Down) &&
                !sf::Keyboard::isKeyPressed(sf::Keyboard::Left) &&
                !sf::Keyboard::isKeyPressed(sf::Keyboard::Right) &&
                !sf::Keyboard::isKeyPressed(sf::Keyboard::Enter)) {
                keyPressed = false;
            }
        }
        else if (state == PLAYING) {
            // Paddle Movement
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
                paddle.move(-paddle.speed * dt);
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
                paddle.move(paddle.speed * dt);
            }

            // Save game with S key
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)) {
                saveGame(ball, paddle, score, lives, level);
                drawFancyText(window, "GAME SAVED!", font, 40, 520, 350,
                    sf::Color::Green, sf::Color::Black, 2.f, true);
                window.display();
                sf::sleep(sf::seconds(0.5));
                continue;
            }

            // Pause game with P key
            static bool pKeyPressed = false;
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::P)) {
                if (!pKeyPressed) {
                    state = PAUSED;
                    saveGame(ball, paddle, score, lives, level);
                    pKeyPressed = true;
                }
            }
            else {
                pKeyPressed = false;
            }

            // Ball movement and collisions
            ball.update(dt);

            // Ball bounce on left/right walls
            if (ball.shape.getPosition().x - ball.shape.getRadius() < 0) {
                ball.velocity.x = std::abs(ball.velocity.x);
                if (sfxOn) hitSound.play();
            }
            else if (ball.shape.getPosition().x + ball.shape.getRadius() > 1280) {
                ball.velocity.x = -std::abs(ball.velocity.x);
                if (sfxOn) hitSound.play();
            }

            // Ball bounce on top wall
            if (ball.shape.getPosition().y - ball.shape.getRadius() < 0) {
                ball.velocity.y = std::abs(ball.velocity.y);
                if (sfxOn) hitSound.play();
            }

            // Ball falls below screen
            if (ball.shape.getPosition().y - ball.shape.getRadius() > 720) {
                lives--;
                if (lives <= 0) {
                    if (score > highScore) highScore = score;
                    state = GAME_OVER;
                }
                else {
                    ball = Ball(640.f, 500.f);
                    paddle = Paddle(640.f, 680.f);
                }
            }

            // Ball collision with paddle
            if (ball.shape.getGlobalBounds().intersects(paddle.shape.getGlobalBounds())) {
                ball.velocity.y = -std::abs(ball.velocity.y);
                if (sfxOn) hitSound.play();
            }

            // Ball collision with bricks
            for (auto& brick : bricks) {
                if (!brick.destroyed && ball.shape.getGlobalBounds().intersects(brick.shape.getGlobalBounds())) {
                    brick.destroyed = true;
                    score += 10;
                    ball.velocity.y = -ball.velocity.y;
                    if (sfxOn) hitSound.play();
                    break;
                }
            }

            // Remove destroyed bricks
            bricks.erase(std::remove_if(bricks.begin(), bricks.end(),
                [](const Brick& b) { return b.destroyed; }),
                bricks.end());

            // If all bricks destroyed, next level
            if (bricks.empty()) {
                level++;
                resetBricks(bricks, level);
                ball = Ball(640.f, 500.f);
                paddle = Paddle(640.f, 680.f);
            }

            // Draw all game elements
            window.draw(paddle.shape);
            window.draw(ball.shape);
            for (auto& brick : bricks) {
                window.draw(brick.shape);
            }

            // Draw Score and Lives with fancy appearance
            drawFancyText(window, "SCORE: " + std::to_string(score), font, 30, 20, 10,
                sf::Color::White, sf::Color::Black, 1.5f, true);
            drawFancyText(window, "LIVES: " + std::to_string(lives), font, 30, 1100, 10,
                sf::Color::White, sf::Color::Black, 1.5f, true);
            drawFancyText(window, "LEVEL: " + std::to_string(level), font, 30, 580, 10,
                sf::Color::White, sf::Color::Black, 1.5f, true);

            // Controls hint during gameplay
            drawFancyText(window, "P: Pause  |  S: Save  |  ESC: Menu", font, 20, 500, 680,
                sf::Color(180, 180, 180), sf::Color::Transparent, 0.f);
        }
        else if (state == PAUSED) {
            drawFancyText(window, "GAME PAUSED", font, 70, 460, 250,
                sf::Color(255, 215, 0), sf::Color(139, 69, 19), 3.f, true);

            drawFancyText(window, "Press P to Resume", font, 36, 530, 350);
            drawFancyText(window, "Press ESC to Return to Main Menu", font, 36, 450, 400);

            drawFancyText(window, "Game Progress:", font, 30, 530, 470,
                sf::Color(100, 255, 100), sf::Color::Transparent, 0.f, true);

            drawFancyText(window, "Score: " + std::to_string(score), font, 28, 530, 520);
            drawFancyText(window, "Lives: " + std::to_string(lives), font, 28, 530, 560);
            drawFancyText(window, "Level: " + std::to_string(level), font, 28, 530, 600);

            static bool pKeyPressed = false;
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::P)) {
                if (!pKeyPressed) {
                    state = PLAYING;
                    pKeyPressed = true;
                }
            }
            else {
                pKeyPressed = false;
            }
        }
        else if (state == GAME_OVER) {
            drawFancyText(window, "GAME OVER", font, 80, 440, 200,
                sf::Color::Red, sf::Color::Black, 4.f, true);

            drawFancyText(window, "Your Score: " + std::to_string(score), font, 50, 520, 300);
            drawFancyText(window, "High Score: " + std::to_string(highScore), font, 50, 490, 380);

            drawFancyText(window, "Press ENTER to Start New Game", font, 36, 450, 500);
            drawFancyText(window, "Press ESC to Return to Main Menu", font, 36, 430, 560);

            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter)) {
                score = 0; lives = 3; level = 1;
                ball = Ball(640.f, 500.f);
                paddle = Paddle(640.f, 680.f);
                resetBricks(bricks, level);
                state = PLAYING;
            }
        }

        window.display();
    }

    return 0;
}
